# frozen_string_literal: true
module Psych
  class Omap < ::Hash
  end
end
